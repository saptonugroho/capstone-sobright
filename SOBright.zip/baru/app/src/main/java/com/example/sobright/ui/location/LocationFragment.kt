package com.example.sobright.ui.location

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.fragment.app.Fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.annotation.ColorInt
import androidx.annotation.DrawableRes
import androidx.appcompat.widget.SearchView
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.DrawableCompat
import com.example.sobright.R
import com.example.sobright.ui.calculation.CalculationFragment
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions


class LocationFragment : Fragment(), OnMapReadyCallback {
    private lateinit var mMap : GoogleMap
    private lateinit var searchView: SearchView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_location, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(this)

        searchView = view.findViewById(R.id.searchView)
        setupSearchView()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.setOnPoiClickListener { pointOfInterest ->
            val poiMarker = mMap.addMarker(
                MarkerOptions()
                    .position(pointOfInterest.latLng)
                    .title(pointOfInterest.name)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)) // Menggunakan warna hijau
            )
            poiMarker?.showInfoWindow()
        }
    }

    private val locations: List<LocationData> = listOf(
        LocationData("Daerah Istimewa Yogyakarta", LatLng(-7.79918, 110.37200), "Daerah Istimewa Yogyakarta"),
        LocationData("Surakarta", LatLng(-7.757591, 110.82338), "Surakarta"),
        LocationData("Kebumen", LatLng(-7.67097, 109.65740), "Kebumen"),
    )

    private fun setupSearchView() {
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (!query.isNullOrBlank()) {
                    performSearch(query)
                }
                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                return true
            }
        })
    }

    private fun performSearch(query: String) {
        val filteredLocations = locations.filter {
            it.name.contains(query, true) || it.address.contains(query, true)
        }

        filteredLocations.forEach { location ->
            addMarker(location.name, location.position, location.address)
        }
        if (filteredLocations.isNotEmpty()) {
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(filteredLocations.first().position, 12f))
        }
    }

    private fun addMarker(title: String, position: LatLng, snippet: String) {
        val markerOptions = MarkerOptions()
            .position(position)
            .title(title)
            .snippet(snippet)

        when (title) {
            "Daerah Istimewa Yogyakarta" -> markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
            "Surakarta" -> markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
            "Kebumen" -> markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW))
            else -> {
            }
        }

        mMap.addMarker(markerOptions)


    }


    data class LocationData(val name: String, val position: LatLng, val address: String)
}